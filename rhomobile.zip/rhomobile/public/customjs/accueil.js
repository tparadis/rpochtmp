function init() {
	parcours = sessionStorage;
	parcours.clear();
}
//window.onload = init();

